#include<iostream>
#include<string>
#include "MyQueue.h"

using namespace std;


string GoodString(string s)
{
    Stack<char> sta(s.length());

    for (int i = 0; i < s.length(); i++)
    {
        char c = s[i];

        if (!sta.isempty())
        {
            char top = sta.Top();
            bool sameLetter = (top == c + 32) || (top == c - 32);
            bool differentCase = (top >= 'A' && top <= 'Z' && c >= 'a' && c <= 'z') ||
                (top >= 'a' && top <= 'z' && c >= 'A' && c <= 'Z');

            if (sameLetter && differentCase)
            {
                sta.pop();
            }
            else
            {
                sta.push(c);
            }
        }
        else
        {
            sta.push(c);
        }
    }

    string result;
    while (!sta.isempty())
    {
        result = sta.pop() + result;
    }

    return result;
}

int main()
{
    MyQueue<int>* queue = new MyQueue<int>();

    queue->enqueue(5);
    queue->enqueue(10);
    queue->enqueue(30);

    int frnt = queue->front();
    cout << "The front value: " << frnt << endl;

    int deque = queue->dequeue();
    cout << "Dequeued value: " << deque << endl;

    bool isEmpty = queue->emptyqueue();
    if (isEmpty)
    {
        cout << "Is the queue empty? Yes" << endl;
    }
    else
    {
        cout << "Is the queue empty? No" << endl;
    }

    string tst1 = "leEeetcode";
    string tst2 = "abBAcC";
    string tst3 = "s";

    cout << "Making '" << tst1 << "' good: " << GoodString(tst1) << endl;
    cout << "Making '" << tst2 << "' good: " << GoodString(tst2) << endl;
    cout << "Making '" << tst3 << "' good: " << GoodString(tst3) << endl;

    delete queue;

    return 0;
}
