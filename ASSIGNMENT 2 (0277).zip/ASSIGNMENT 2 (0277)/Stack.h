#pragma once
#include<iostream>
using namespace std;

// Stack class
template<typename T>
class Stack
{
private:
    T* array;
    int position;
    int size;

public:
    Stack(int s)
    {
        size = s;
        array = new T[s];
        position = 0;
    }

    ~Stack()
    {
        delete[] array;
    }

    void push(T value)
    {
        if (!isfull())
        {
            array[position++] = value;
        }
    }

    T pop()
    {
        if (!isempty())
        {
            T value = array[--position];
            return value;
        }
        else
        {
            cout << "Stack is empty" << endl;
            return T();
        }
    }

    T Top()
    {
        if (!isempty())
        {
            return array[position - 1];
        }
        else
        {
            return T();
        }
    }

    void display()
    {
        for (int i = 0; i < position; i++)
        {
            cout << array[i] << "   " << endl;
        }
    }

    bool isfull()
    {
        return size == position;
    }

    bool isempty()
    {
        return position == 0;
    }
};
