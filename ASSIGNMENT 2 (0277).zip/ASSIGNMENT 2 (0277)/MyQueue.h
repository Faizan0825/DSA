#pragma once
#include "Stack.h"
using namespace std;

// MyQueue class using two stacks
template<typename T>
class MyQueue
{
private:
    Stack<int> sta1{ 5 };
    Stack<int> sta2{ 5 };

public:
    void enqueue(T value)
    {
        sta1.push(value);
    }

    T dequeue()
    {
        if (sta2.isempty())
        {
            while (!sta1.isempty())
            {
                sta2.push(sta1.pop());
            }
        }

        if (!sta2.isempty())
        {
            return sta2.pop();
        }
        else
        {
            cout << "Queue is empty" << endl;
            return T();
        }
    }

    T front()
    {
        if (sta2.isempty())
        {
            while (!sta1.isempty())
            {
                sta2.push(sta1.pop());
            }
        }

        if (!sta2.isempty())
        {
            return sta2.Top();
        }
        else
        {
            cout << "Queue is empty" << endl;
            return T();
        }
    }

    bool emptyqueue()
    {
        return sta1.isempty() && sta2.isempty();
    }
};
