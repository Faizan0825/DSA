//#include <iostream>
//using namespace std;
//
//class Node
//{
//public:
//    int data;
//    Node* next;
//};
//
//class LinkedList
//{
//private:
//    Node* head;
//
//public:
//    LinkedList()
//    {
//        head = NULL;
//    }
//
//    void addNode(int value)
//    {
//        Node* newNode = new Node;
//        newNode->data = value;
//        newNode->next = NULL;
//
//        if (head == NULL)
//        {
//            head = newNode;
//            return;
//        }
//
//        Node* temp = head;
//        while (temp->next != NULL)
//        {
//            temp = temp->next;
//        }
//
//        temp->next = newNode;
//    }
//
//    void print()
//    {
//        Node* temp = head;
//        while (temp != NULL)
//        {
//            cout << temp->data << " ";
//            temp = temp->next;
//        }
//        cout << endl;
//    }
//
//    Node* getHead()
//    {
//        return head;
//    }
//
//    void setHead(Node* h)
//    {
//        head = h;
//    }
//};
//
//// Remove duplicates (iterative)
//void removeDuplicates(Node*& head)
//{
//    if (head == NULL) return;
//
//    Node* current = head;
//    while (current != NULL && current->next != NULL)
//    {
//        if (current->data == current->next->data)
//        {
//            Node* duplicate = current->next;
//            current->next = current->next->next;
//            delete duplicate;
//        }
//        else
//        {
//            current = current->next;
//        }
//    }
//}
//
//// Remove duplicates (recursive)
//void removeDuplicatesRecursive(Node*& head)
//{
//    if (head == NULL || head->next == NULL)
//        return;
//
//    if (head->data == head->next->data)
//    {
//        Node* duplicate = head->next;
//        head->next = head->next->next;
//        delete duplicate;
//        removeDuplicatesRecursive(head);
//    }
//    else
//    {
//        removeDuplicatesRecursive(head->next);
//    }
//}
//
//int main()
//{
//    LinkedList list;
//
//    list.addNode(5);
//    list.addNode(5);
//    list.addNode(5);
//    list.addNode(7);
//    list.addNode(7);
//    list.addNode(9);
//    list.addNode(11);
//    list.addNode(13);
//    list.addNode(13);
//    list.addNode(15);
//    list.addNode(15);
//
//    cout << "Original List: ";
//    list.print();
//
//    Node* head = list.getHead();
//    removeDuplicates(head);
//    list.setHead(head);
//    cout << "After Removing Duplicates (Iterative): ";
//    list.print();
//
//    head = list.getHead();
//    removeDuplicatesRecursive(head);
//    list.setHead(head);
//    cout << "After Removing Duplicates (Recursive): ";
//    list.print();
//
//    return 0;
//}
