#include <iostream>
using namespace std;

class Node
{
public:
    int item_id;
    float price;
    int quantity;
    Node* next;

    Node(int id, float pr, int qty)
    {
        item_id = id;
        price = pr;
        quantity = qty;
        next = nullptr;
    }
};

class Inventory
{
private:
    Node* head;

public:
    Inventory()
    {
        head = nullptr;
    }

    void addItem(int id, float price, int quantity)
    {
        Node* newNode = new Node(id, price, quantity);
        if (head == nullptr)
        {
            head = newNode;
        }
        else
        {
            Node* temp = head;
            while (temp->next != nullptr)
                temp = temp->next;
            temp->next = newNode;
        }
    }

    void removeDuplicates()
    {
        Node* current = head;
        while (current != nullptr && current->next != nullptr)
        {
            if (current->item_id == current->next->item_id)
            {
                Node* dup = current->next;
                current->next = dup->next;
                delete dup;
            }
            else
            {
                current = current->next;
            }
        }
    }

    void display()
    {
        Node* temp = head;
        while (temp != nullptr)
        {
            cout << "Item ID: " << temp->item_id
                << ", Price: " << temp->price
                << ", Quantity: " << temp->quantity << endl;
            temp = temp->next;
        }
    }

    ~Inventory()
    {
        Node* temp;
        while (head != nullptr)
        {
            temp = head;
            head = head->next;
            delete temp;
        }
    }
};

int main()
{
    Inventory inv;
    inv.addItem(101, 10.5, 5);
    inv.addItem(101, 10.5, 5); // Duplicate
    inv.addItem(102, 20.0, 2);
    inv.addItem(103, 15.0, 3);
    inv.addItem(103, 15.0, 3); // Duplicate

    cout << "Before removing duplicates:" << endl;
    inv.display();

    inv.removeDuplicates();

    cout << "After removing duplicates:" << endl;
    inv.display();

    return 0;
}
