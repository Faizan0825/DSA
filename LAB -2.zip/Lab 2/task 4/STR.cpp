//#include "STR.h"
//#include<string>
//
//template<typename T>
//STR<T>::STR(T newval) {
//    value = newval;
//}
//
//template<typename T>
//void STR<T>::setvalue(T val) {
//    value = val;
//}
//
//template<typename T>
//T STR<T>::getvalue() {
//    return value;
//}
//
//
//template class STR<int>;
//
