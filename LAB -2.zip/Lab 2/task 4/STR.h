//
//template<typename T>
//class STR
//{
//private:
//    T value;
//
//public:
//    STR(T newval);
//    void setvalue(T val);
//    T getvalue();
//};
//
//
