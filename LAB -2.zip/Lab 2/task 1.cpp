//#include<iostream>
//using namespace std;
//
//template <typename T>
//void swap1(T& num1, T& num2)
//{
//    T temp = num1;
//
//    num1 = num2;
//    num2 = temp;
//    cout << "The value of A is " << num1 << endl;
//    cout << "The value of B is " << num2 << endl;
//}
//
//int main()
//{
//    double  a = 5;
//    double  b = 7;
//    cout << "The before value of A is " << a << endl;
//    cout << "The before of B is " << b << endl;
//    cout << endl;
//    cout << endl;
//
//    swap1<double >(a, b);  
//
//    return 0;
//}
