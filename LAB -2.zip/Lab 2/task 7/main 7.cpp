#include <iostream>
#include "MyList.h"

using namespace std;

int main() {
    MyList<int> list;
    int choice, value, index;

    do {
        cout << "\nMenu:\n";
        cout << "1. Insert\n";
        cout << "2. Check Empty\n";
        cout << "3. Check Full\n";
        cout << "4. Get Size\n";
        cout << "5. Get Last Element\n";
        cout << "6. Search Element\n";
        cout << "7. Display List\n";
        cout << "0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter index and value: ";
            cin >> index >> value;
            if (list.insert(index, value)) {
                cout << "Inserted successfully!\n";
            }
            else {
                cout << "Insertion failed!\n";
            }
            break;
        case 2:
            cout << (list.empty() ? "List is empty.\n" : "List is not empty.\n");
            break;
        case 3:
            cout << (list.full() ? "List is full.\n" : "List is not full.\n");
            break;
        case 4:
            cout << "Size: " << list.size() << endl;
            break;
        case 5:
            cout << "Last Element: " << list.last() << endl;
            break;
        case 6:
            cout << "Enter value to search: ";
            cin >> value;
            cout << (list.search(value) ? "Value found!\n" : "Value not found!\n");
            break;
        case 7:
            cout << "List: ";
            list.display();
            break;
        }
    } while (choice != 0);

    return 0;
}
