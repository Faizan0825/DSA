#include <iostream>

template <typename T>
class MyList 
{
private:
    T* arr;
    int capacity;
    int count;

public:
    MyList(int size = 10);
    MyList(const MyList& other);
    ~MyList();

    bool empty();
    bool full();
    int size();
    bool insert(int index, T value);
    T last();
    bool search(T value);
    void display();
};
