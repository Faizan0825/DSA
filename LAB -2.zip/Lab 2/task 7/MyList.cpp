#include "MyList.h"


template <typename T>
MyList<T>::MyList(int size)
{
    capacity = size;
    count = 0;
    arr = new T[capacity];
}


template <typename T>
MyList<T>::MyList(const MyList& other) 
{
    capacity = other.capacity;
    count = other.count;
    arr = new T[capacity];
    for (int i = 0; i < count; i++) {
        arr[i] = other.arr[i];
    }
}

template <typename T>
MyList<T>::~MyList() 
{
    delete[] arr;
}


template <typename T>
bool MyList<T>::empty() 
{
    return count == 0;
}


template <typename T>
bool MyList<T>::full()
{
    return count == capacity;
}


template <typename T>
int MyList<T>::size() 
{
    return count;
}

template <typename T>
bool MyList<T>::insert(int index, T value) 
{
    if (index < 0 || index > count || full())
    {
        return false;
    }
    for (int i = count; i > index; i--)
    {
        arr[i] = arr[i - 1];
    }
    arr[index] = value;
    count++;
    return true;
}


template <typename T>
T MyList<T>::last()
{
    if (!empty()) 
    {
        return arr[count - 1];
    }
    return T(); 


template <typename T>
bool MyList<T>::search(T value) 
{
    for (int i = 0; i < count; i++) 
    {
        if (arr[i] == value)
        {
            return true;
        }
    }
    return false;
}

template <typename T>
void MyList<T>::display() 
{
    for (int i = 0; i < count; i++)
    {
        std::cout << arr[i] << " ";
    }
    std::cout << std::endl;
}

