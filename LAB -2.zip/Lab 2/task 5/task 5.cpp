#include <iostream>

using namespace std;

template <typename T>
class ArrayOperations {
private:
    T* arr;
    int size;

public:
    ArrayOperations(int size) {
        this->size = size;
        arr = new T[size];
    }

    ~ArrayOperations() {
        delete[] arr;
    }

    void setElement(int index, T value) {
        if (index >= 0 && index < size) {
            arr[index] = value;
        }
    }

    T getElement(int index) {
        if (index >= 0 && index < size) {
            return arr[index];
        }
        return T();
    }

    T findMin() {
        T minVal = arr[0];
        for (int i = 1; i < size; i++) {
            if (arr[i] < minVal) {
                minVal = arr[i];
            }
        }
        return minVal;
    }

    T findMax() {
        T maxVal = arr[0];
        for (int i = 1; i < size; i++) {
            if (arr[i] > maxVal) {
                maxVal = arr[i];
            }
        }
        return maxVal;
    }

    void reverseArray() {
        int left = 0;
        int right = size - 1;
        while (left < right) {
            T temp = arr[left];
            arr[left] = arr[right];
            arr[right] = temp;
            left++;
            right--;
        }
    }

    void inputElements() {
        cout << "Enter the elements of the array:\n";
        for (int i = 0; i < size; ++i) {
            cin >> arr[i];
        }
    }

    void displayArray() {
        cout << "Array: ";
        for (int i = 0; i < size; i++) {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
};

int main() {
    int size;
    cout << "Enter the size of the array: ";
    cin >> size;

    ArrayOperations<int> arrayOps(size);
    arrayOps.inputElements();

    cout << "Minimum value: " << arrayOps.findMin() << endl;
    cout << "Maximum value: " << arrayOps.findMax() << endl;

    int index, value;
    cout << "Enter index to set a value: ";
    cin >> index;
    cout << "Enter value to set at index " << index << ": ";
    cin >> value;
    arrayOps.setElement(index, value);
    cout << "Element at index " << index << " is now: " << arrayOps.getElement(index) << endl;

    arrayOps.reverseArray();
    cout << "Reversed array: ";
    arrayOps.displayArray();

    return 0;
}
