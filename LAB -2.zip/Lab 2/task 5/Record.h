//
//class Record
//{
//private:
//	char* name;
//	double score;
//public:
//	Record(char* n, double s);
//	void display();
//
//
//};
//
