
#include "List.h"

    template <typename Type>
    class ArrayList : public List<Type>
    {
    public:
        ArrayList(int size = 10);

        void addElementAtFirstIndex(Type element) override;
        void addElementAtLastIndex(Type element) override;
        Type removeElementFromEnd() override;
        void removeElementFromStart() override;
    };



