#include "ArrayList.h"
#include<iostream>
using namespace std;
int main() 
{
    ArrayList<int> myList(5);

    myList.addElementAtLastIndex(10);
    myList.addElementAtLastIndex(20);
    myList.addElementAtFirstIndex(5);
    myList.printList();

    myList.removeElementFromEnd();
    myList.printList();

    myList.removeElementFromStart();
    myList.printList();

    return 0;
}
