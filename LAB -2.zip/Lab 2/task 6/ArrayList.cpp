#include "ArrayList.h"

template <typename Type>
ArrayList<Type>::ArrayList(int size) : List<Type>(size) 
{}

template <typename Type>
void ArrayList<Type>::addElementAtFirstIndex(Type element) 
{
    if (this->currentSize >= this->maxSize)
    {
        cout << "List is full, cannot add element at first index.\n";
        return;
    }
    for (int i = this->currentSize; i > 0; i--)
    {
        this->arr[i] = this->arr[i - 1];
    }
    this->arr[0] = element;
    this->currentSize++;
}

template <typename Type>
void ArrayList<Type>::addElementAtLastIndex(Type element) 
{
    if (this->currentSize >= this->maxSize) 
    {
        cout << "List is full, cannot add element at last index.\n";
        return;
    }
    this->arr[this->currentSize] = element;
    this->currentSize++;
}

template <typename Type>
Type ArrayList<Type>::removeElementFromEnd() 
{
    if (this->currentSize == 0)
    {
        cout << "List is empty, cannot remove element from end.\n";
        return Type();
    }
    this->currentSize--;
    return this->arr[this->currentSize];
}

template <typename Type>
void ArrayList<Type>::removeElementFromStart()
{
    if (this->currentSize == 0)
    {
        cout << "List is empty, cannot remove element from start.\n";
        return;
    }
    for (int i = 0; i < this->currentSize - 1; i++) {
        this->arr[i] = this->arr[i + 1];
    }
    this->currentSize--;
}

template class ArrayList<int>;
