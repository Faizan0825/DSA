//Faizan Akbar   (l1f23bscs0277)
//Ibraiz Raza    (l1f23bscs0278)
//project 1


#include <iostream>
using namespace std;

class Node {
public:
	Node* left;
	Node* right;
	int data;
	Node(int d) {
		data = d;
		left = nullptr;
		right = nullptr;
	}
};

template <typename T>
class Queue {
private:
	T arr[100];
	int front;
	int rear;
public:
	Queue() {
		front = 0;
		rear = 0;
	}
	bool isEmpty() {
		return front == rear;
	}
	void enqueue(T val) {
		if (rear == 100) {
			cout << "Queue is full" << endl;
		}
		else {
			arr[rear++] = val;
		}
	}
	T dequeue() {
		if (isEmpty()) {
			cout << "Queue is empty" << endl;
			return NULL;
		}
		return arr[front++];
	}
	int size() {
		return rear - front;
	}
};

Node* insert_in_Bst(Node* root, int d) {
	if (root == nullptr) {
		return new Node(d);
	}
	else if (d < root->data) {
		root->left = insert_in_Bst(root->left, d);
	}
	else {
		root->right = insert_in_Bst(root->right, d);
	}
	return root;
}

void inorder(Node* r) {
	if (r == nullptr) {
		return;
	}
	inorder(r->left);
	cout << r->data << ' ';
	inorder(r->right);
}

void preorder(Node* r) {
	if (r == nullptr) {
		return;
	}
	cout << r->data << ' ';
	preorder(r->left);
	preorder(r->right);
}

void postorder(Node* r) {
	if (r == nullptr) {
		return;
	}
	postorder(r->left);
	postorder(r->right);
	cout << r->data << ' ';
}

Node* getSuccessor(Node* cur) {
	cur = cur->right;
	while ((cur != nullptr) && (cur->left != nullptr)) {
		cur = cur->left;
	}
	return cur;
}

Node* delete_Node(Node* root, int d) {
	if (root == nullptr) {
		return nullptr;
	}
	if (d < root->data) {
		root->left = delete_Node(root->left, d);
	}
	else if (d > root->data) {
		root->right = delete_Node(root->right, d);
	}
	else {
		if ((root->left == nullptr) && (root->right == nullptr)) {
			delete root;
			return nullptr;
		}
		if (root->right == nullptr) {
			Node* t = root->left;
			delete root;
			return t;
		}
		if (root->left == nullptr) {
			Node* t = root->right;
			delete root;
			return t;
		}
		Node* succ = getSuccessor(root);
		root->data = succ->data;
		root->right = delete_Node(root->right, succ->data);
	}
	return root;
}

void LevelOrder(Node* root) {
	if (root == nullptr) {
		return;
	}
	Queue<Node*> Q;
	Q.enqueue(root);
	while (!Q.isEmpty()) {
		int levelSize = Q.size();
		for (int i = 0; i < levelSize; i++) {
			Node* cur = Q.dequeue();
			cout << cur->data << ' ';
			if (cur->left != nullptr) {
				Q.enqueue(cur->left);
			}
			if (cur->right != nullptr) {
				Q.enqueue(cur->right);
			}
		}
		cout << endl;
	}
}

int distanceFromRoot(Node* root, int x) {
	if (root == nullptr) {
		return -1;
	}
	if (root->data == x) {
		return 0;
	}
	else if (x < root->data) {
		int d = distanceFromRoot(root->left, x);
		if (d == -1) {
			return -1;
		}
		else {
			return 1 + d;
		}
	}
	else {
		int d = distanceFromRoot(root->right, x);
		if (d == -1) {
			return -1;
		}
		else {
			return 1 + d;
		}
	}
}

int distanceBetweenTwoKeys(Node* root, int a, int b) {
	if (root == nullptr) {
		return -1;
	}
	if ((a < root->data) && (b < root->data)) {
		return distanceBetweenTwoKeys(root->left, a, b);
	}
	if ((a > root->data) && (b > root->data)) {
		return distanceBetweenTwoKeys(root->right, a, b);
	}
	int d1 = distanceFromRoot(root, a);
	int d2 = distanceFromRoot(root, b);
	if ((d1 == -1) || (d2 == -1)) {
		cout << "Invalid Input for finding Path" << endl;
		return -1;
	}
	return d1 + d2;
}

void printPath(int path[], int len) {
	for (int i = 0; i < len; i++) {
		cout << path[i];
		if (i < len - 1) {
			cout << " -> ";
		}
	}
	cout << endl;
}

void displayRootToLeafPaths(Node* root, int path[], int len) {
	if (root == nullptr) {
		return;
	}
	path[len++] = root->data;
	if ((root->left == nullptr) && (root->right == nullptr)) {
		printPath(path, len);
	}
	else {
		displayRootToLeafPaths(root->left, path, len);
		displayRootToLeafPaths(root->right, path, len);
	}
}

bool searchAndShowPath(Node* root, int key) {
	if (root == nullptr) {
		cout << "Key not found in tree." << endl;
		return false;
	}
	cout << root->data;
	if (root->data == key) {
		cout << " <- Found!" << endl;
		return true;
	}
	cout << " -> ";
	if (key < root->data) {
		return searchAndShowPath(root->left, key);
	}
	else {
		return searchAndShowPath(root->right, key);
	}
}
int height(Node* r)
{
	if (r == nullptr)
	{
		return -1;
	}
	int hl = height(r->left);
	int hr = height(r->right);
	if (hl>hr)
	{
		return hl + 1;
	}
	else
	{
		return hr + 1;
	}
}

int countLeaf(Node* r)
{
	if (r == nullptr)
	{
		return 0;
	}
	if (r->left == nullptr&&r->right == nullptr)
	{
		return 1;
	}
	return countLeaf(r->left) + countLeaf(r->right);
}

int countNodes(Node* r){
	if (r == nullptr)
	{
		return 0;
	}
	return 1 + countNodes(r->left) + countNodes(r->right);
}

void stats(Node* root){
	int h = height(root);
	int leaves = countLeaf(root);
	int total = countNodes(root);
	int internal = total - leaves;
	int bf = height(root->left) - height(root->right);
	cout << "Height: " << h << endl;
	cout << "Leaf nodes: " << leaves << endl;
	cout << "Internal nodes: " << internal << endl;
	cout << "Balance factor of root: " << bf << endl;
}
void printIndented(Node* root, int space)
{
	if (root == nullptr)
	{
		return;
	}
	printIndented(root->right, space + 4);
	for (int i = 0; i<space; i++)
	{
		cout << ' ';
	}
	cout << root->data << endl;
	printIndented(root->left, space + 4);
}

int main() {
	Node* root = nullptr;
	int choice;
	int val, val2;

	do {
		cout << endl;
		cout << "0. Exit" << endl;
		cout << "1. Insert a node" << endl;
		cout << "2. Delete a node" << endl;
		cout << "3. Search for a node and show path" << endl;
		cout << "4. Find path between two nodes" << endl;
		cout << "5. Display all root-to-leaf paths" << endl;
		cout << "6. Show inorder traversal" << endl;
		cout << "7. Show preorder traversal" << endl;
		cout << "8. Show postorder traversal" << endl;
		cout << "9. Show level-order traversal" << endl;
		cout << "10. Display tree (indentation format)" << endl;
		cout << "11 Show tree statistics (height, leaf/internal nodes, balance factor) " << endl;
		cout << "Enter your choice: ";
		cin >> choice;


		if (choice == 0) {
		}
		else if (choice == 1) {
			cout << "Enter value to insert: ";
			cin >> val;
			root = insert_in_Bst(root, val);
		}
		else if (choice == 2) {
			cout << "Enter value to delete: ";
			cin >> val;
			root = delete_Node(root, val);
		}
		else if (choice == 3) {
			cout << "Enter value to search: ";
			cin >> val;
			searchAndShowPath(root, val);
		}
		else if (choice == 4) {
			cout << "Enter two values to find path between: ";
			cin >> val >> val2;
			cout << "Distance: " << distanceBetweenTwoKeys(root, val, val2) << endl;
		}
		else if (choice == 5) {
			int path[100];
			cout << "Root to Leaf Paths:" << endl;
			displayRootToLeafPaths(root, path, 0);
		}
		else if (choice == 6) {
			cout << "Inorder: ";
			inorder(root);
			cout << endl;
		}
		else if (choice == 7) {
			cout << "Preorder: ";
			preorder(root);
			cout << endl;
		}
		else if (choice == 8) {
			cout << "Postorder: ";
			postorder(root);
			cout << endl;
		}
		else if (choice == 9) {
			cout << "Level Order Traversal:" << endl;
			LevelOrder(root);
		}
		else if (choice == 10){
			cout << "Indented Tree:" << endl;
			printIndented(root, 0);
		}
		else if (choice == 11)
		{
			stats(root);
			cout << endl;
		}
		else {
			cout << "Invalid choice!" << endl;
		}

	} while (choice != 0);

	system("pause");
	return 0;
}