#ifndef REVERSE_ELEMENTS_H
#define REVERSE_ELEMENTS_H

template <typename Type>
Type* reverseElements(Type* arr, int size);

bool isPalindrome(int* arr, int size);

#endif
