#include "reverse_elements.h"
#include <queue>
using namespace std;

template <typename Type>
Type* reverseElements(Type* arr, int size) {
    queue<Type> q1, q2;

    for (int i = 0; i < size; i++) q1.push(arr[i]);

    for (int i = size - 1; i >= 0; i--) {
        queue<Type> temp = q1;
        for (int j = 0; j < i; j++) temp.pop();
        q2.push(temp.front());
    }

    Type* reversed = new Type[size];
    for (int i = 0; i < size; i++) {
        reversed[i] = q2.front();
        q2.pop();
    }

    return reversed;
}

bool isPalindrome(int* arr, int size) {
    for (int i = 0; i < size / 2; i++) {
        if (arr[i] != arr[size - 1 - i])
            return false;
    }
    return true;
}

template int* reverseElements<int>(int*, int);
