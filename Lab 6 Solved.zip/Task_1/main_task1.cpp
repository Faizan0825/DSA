#include "reverse_elements.h"
#include <iostream>
using namespace std;

int main() {
    int arr1[] = {1, 2, 3, 2, 1};
    int size1 = 5;

    int* rev1 = reverseElements(arr1, size1);

    cout << "Reversed: ";
    for (int i = 0; i < size1; i++) cout << rev1[i] << " ";

    cout << "\nIs Palindrome: " << (isPalindrome(arr1, size1) ? "Yes" : "No") << endl;

    delete[] rev1;
    return 0;
}
