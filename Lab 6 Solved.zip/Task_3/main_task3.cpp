#include "circular_queue.h"
#include <iostream>
using namespace std;

int main() {
    CircularQueue<int> cq(5);
    cq.enqueue(10);
    cq.enqueue(20);
    cq.enqueue(30);
    cq.enqueue(40);
    cq.enqueue(50);
    cq.dequeue();
    cq.enqueue(60);

    cq.display(); // Expected: 20 30 40 50 60

    return 0;
}
