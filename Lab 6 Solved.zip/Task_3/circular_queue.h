#ifndef CIRCULAR_QUEUE_H
#define CIRCULAR_QUEUE_H

using namespace std;

template <typename T>
class CircularQueue {
private:
    T* arr;
    int frontIndex, rearIndex, capacity, count;

public:
    CircularQueue(int size);
    ~CircularQueue();

    bool enqueue(T element);
    T dequeue();
    T front();
    bool isEmpty();
    bool isFull();
    void display();
};

#endif
