#include "circular_queue.h"
#include <iostream>
using namespace std;

template <typename T>
CircularQueue<T>::CircularQueue(int size) {
    capacity = size;
    arr = new T[capacity];
    frontIndex = 0;
    rearIndex = -1;
    count = 0;
}

template <typename T>
CircularQueue<T>::~CircularQueue() {
    delete[] arr;
}

template <typename T>
bool CircularQueue<T>::enqueue(T element) {
    if (isFull()) return false;
    rearIndex = (rearIndex + 1) % capacity;
    arr[rearIndex] = element;
    count++;
    return true;
}

template <typename T>
T CircularQueue<T>::dequeue() {
    if (isEmpty()) {
        cout << "Queue is empty!\n";
        return T();
    }
    T val = arr[frontIndex];
    frontIndex = (frontIndex + 1) % capacity;
    count--;
    return val;
}

template <typename T>
T CircularQueue<T>::front() {
    if (isEmpty()) {
        cout << "Queue is empty!\n";
        return T();
    }
    return arr[frontIndex];
}

template <typename T>
bool CircularQueue<T>::isEmpty() {
    return count == 0;
}

template <typename T>
bool CircularQueue<T>::isFull() {
    return count == capacity;
}

template <typename T>
void CircularQueue<T>::display() {
    if (isEmpty()) {
        cout << "Queue is empty!\n";
        return;
    }
    int i = frontIndex;
    for (int c = 0; c < count; c++) {
        cout << arr[i] << " ";
        i = (i + 1) % capacity;
    }
    cout << endl;
}

template class CircularQueue<int>;
