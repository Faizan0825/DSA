#ifndef TICKET_COUNTER_H
#define TICKET_COUNTER_H

#include <queue>
#include <string>
using namespace std;

struct Customer {
    string name;
    int serviceTime;

    Customer(string n, int t) : name(n), serviceTime(t) {}
};

void simulateTicketCounter(queue<Customer>& customers);

#endif
