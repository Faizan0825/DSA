#include "ticket_counter.h"
#include <iostream>
using namespace std;

void simulateTicketCounter(queue<Customer>& customers) {
    queue<Customer> normalQueue = customers;
    queue<Customer> vipQueue;
    int servedCount = 0;

    while (!normalQueue.empty() || !vipQueue.empty()) {
        Customer current("", 0);
        if (!vipQueue.empty()) {
            current = vipQueue.front(); vipQueue.pop();
        } else {
            current = normalQueue.front(); normalQueue.pop();
        }

        cout << "Serving: " << current.name << " (Time: " << current.serviceTime << "s)\n";
        servedCount++;

        if (servedCount % 3 == 0 && !normalQueue.empty()) {
            Customer vip = normalQueue.front(); normalQueue.pop();
            cout << ">> VIP Skip: " << vip.name << " moved to VIP queue.\n";
            vipQueue.push(vip);
        }
    }
}
