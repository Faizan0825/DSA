#include "ticket_counter.h"
#include <iostream>
using namespace std;

int main() {
    queue<Customer> customers;
    customers.push(Customer("Ali", 5));
    customers.push(Customer("Sara", 3));
    customers.push(Customer("Usman", 4));
    customers.push(Customer("Zara", 6));
    customers.push(Customer("Ahmed", 2));
    customers.push(Customer("Nida", 4));

    simulateTicketCounter(customers);
    return 0;
}
