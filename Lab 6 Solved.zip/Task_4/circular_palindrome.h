#ifndef CIRCULAR_PALINDROME_H
#define CIRCULAR_PALINDROME_H

#include <queue>
using namespace std;

bool isCircularPalindrome(queue<int> q);

#endif
