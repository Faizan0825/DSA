#include "circular_palindrome.h"
using namespace std;

bool isCircularPalindrome(queue<int> q) {
    const int MAX_SIZE = 100;
    int arr[MAX_SIZE];
    int size = 0;

    while (!q.empty()) {
        arr[size++] = q.front();
        q.pop();
    }

    for (int shift = 0; shift < size; shift++) {
        bool isPal = true;

        for (int i = 0; i < size / 2; i++) {
            int left = (shift + i) % size;
            int right = (shift + size - 1 - i) % size;
            if (arr[left] != arr[right]) {
                isPal = false;
                break;
            }
        }

        if (isPal) return true;
    }

    return false;
}
