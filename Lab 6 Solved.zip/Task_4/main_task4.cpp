#include "circular_palindrome.h"
#include <iostream>
using namespace std;

int main() {
    queue<int> q1;
    q1.push(1); q1.push(2); q1.push(3); q1.push(2); q1.push(1);
    cout << "Queue 1 Circular Palindrome: " << (isCircularPalindrome(q1) ? "Yes" : "No") << endl;

    queue<int> q2;
    q2.push(3); q2.push(1); q2.push(2); q2.push(1); q2.push(3);
    cout << "Queue 2 Circular Palindrome: " << (isCircularPalindrome(q2) ? "Yes" : "No") << endl;

    queue<int> q3;
    q3.push(1); q3.push(2); q3.push(3); q3.push(4); q3.push(5);
    cout << "Queue 3 Circular Palindrome: " << (isCircularPalindrome(q3) ? "Yes" : "No") << endl;

    return 0;
}
