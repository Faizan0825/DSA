#include <iostream>
using namespace std;

class Student 
{
public:
    int id;
    char name[50];
    float cgpa;

    Student()
    {
        id = 0;
        cgpa = 0.0;
        name[0] = '\0';
    }

    friend istream& operator>>(istream& in, Student& s) 
    {
        cout << "Enter ID: ";
        in >> s.id;
        cout << "Enter Name: ";
        in >> s.name;
        cout << "Enter CGPA: ";
        in >> s.cgpa;
        return in;
    }

    friend ostream& operator<<(ostream& out, Student& s) 
    {
        out << "ID: " << s.id << " | Name: " << s.name << " | CGPA: " << s.cgpa;
        return out;
    }

    bool operator<(Student s) 
    {
        return cgpa < s.cgpa;
    }

    bool operator==(Student s)
    {
        return id == s.id;
    }
};

template <class Type>
class Array 
{
private:
    Type* data;
    int capacity;
    int size;

public:
    Array(int c) 
    {
        capacity = c;
        size = 0;
        data = new Type[capacity];
        cout << "Initial array created with size " << capacity << endl;
    }

    ~Array() 
    {
        delete[] data;
    }

    void grow() 
    {
        cout << "Array full. Growing array..." << endl;
        capacity *= 2;
        Type* temp = new Type[capacity];
        for (int i = 0; i < size; i++) 
        {
            temp[i] = data[i];
        }
        delete[] data;
        data = temp;
        cout << "Array size doubled to " << capacity << endl;
    }

    void shrink() {
        if (size <= capacity / 2) 
        {
            capacity /= 2;
            Type* temp = new Type[capacity];
            for (int i = 0; i < size; i++) 
            {
                temp[i] = data[i];
            }
            delete[] data;
            data = temp;
            cout << "Shrinking array..." << endl;
            cout << "Array size reduced to " << capacity << endl;
        }
    }

    void add(Type s)
    {
        if (size == capacity) grow();
        data[size++] = s;
        cout << "Student added: " << s << endl;
    }

    void print()
    {
        cout << "--- Current Student Records ---" << endl;
        for (int i = 0; i < size; i++) {
            cout << i + 1 << ". " << data[i] << endl;
        }
    }

    int search(Type s)
    {
        for (int i = 0; i < size; i++)
        {
            if (data[i] == s) 
            {
                return i;
            }
        }
        return -1;
    }

    void remove() {
        if (size > 0) 
        {
            cout << "Removing last student (" << data[size - 1] << ")" << endl;
            size--;
        }
    }

    void sort() {
        for (int i = 0; i < size - 1; i++) 
        {
            for (int j = i + 1; j < size; j++)
            {
                if (data[i] < data[j])
                {
                    Type temp = data[i];
                    data[i] = data[j];
                    data[j] = temp;
                }
            }
        }
        cout << "Sorting completed." << endl;
    }
};

int main() {
    Array<Student> arr(3);
    cout << "Adding 4 students to array..." << endl;

    Student s;

    for (int i = 0; i < 4; i++)
    {
        cin >> s;
        arr.add(s);
    }

    arr.print();

    cout << "Searching for student: Qasim" << endl;
    Student temp;
    temp.id = 4;
    int index = arr.search(temp);
    if (index != -1)
        cout << "Student found at index: " << index << endl;
    else
        cout << "Student not found" << endl;

    arr.remove();
    arr.shrink();
    arr.sort();
    arr.print();

    return 0;
}