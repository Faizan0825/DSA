//#include "Array.h"
//template<typename T>
//Array<T>::Array(T* arr, int s)
//{
//    if (arr == nullptr)
//    {
//        size = 0;
//        cap = s;
//        arra = new T[cap];
//    }
//    else
//    {
//        size = s;
//        cap = s;
//        arra = new T[cap];
//        for (int i = 0; i < size; i++)
//        {
//            arra[i] = arr[i];
//        }
//    }
//}
//
//template<typename T>
//Array<T>::Array(const Array& other) 
//{
//    size = other.size;
//    cap = other.cap;
//    arra = new T[cap];
//    for (int i = 0; i < size; i++) 
//    {
//        arra[i] = other.arra[i];
//    }
//}
//
//template<typename T>
//Array<T>::~Array()
//{
//    delete[] arra;
//}
//
//template<typename T>
//void Array<T>::display() 
//{
//    cout << "THE ELEMENTS IN ARRAY ARE: ";
//    for (int i = 0; i < size; i++) {
//        cout << arra[i] << " ";
//    }
//    cout << endl;
//}
//
//template<typename T>
//void Array<T>::sort()
//{
//    T temp;
//    for (int i = 0; i < size - 1; i++) 
//    {
//        for (int j = 0; j < size - i - 1; j++) 
//        {
//            if (arra[j] > arra[j + 1]) 
//            {
//                temp = arra[j];
//                arra[j] = arra[j + 1];
//                arra[j + 1] = temp;
//            }
//        }
//    }
//    display();
//}
//
//template<typename T>
//void Array<T>::add(T val) 
//{
//    if (size >= cap)
//    {
//        grow(1);
//    }
//    arra[size] = val;
//    size++;
//    display();
//}
//
//template<typename T>
//void Array<T>::remove() 
//{
//    if (size > 0)
//    {
//        size--;
//        if (size <= cap / 2)
//        {
//            shrink();
//        }
//        display();
//    }
//    else {
//        cout << "Array is empty, cannot remove elements." << endl;
//    }
//}
//
//template<typename T>
//void Array<T>::grow(int increment) 
//{
//    cap += increment;
//    T* newArra = new T[cap];
//    for (int i = 0; i < size; i++)
//    {
//        newArra[i] = arra[i];
//    }
//    delete[] arra;
//    arra = newArra;
//    cout << "Array has grown. New capacity is: " << cap << endl;
//}
//
//template<typename T>
//void Array<T>::shrink() 
//{
//    if (cap > 1) 
//    {
//        cap -= 1;
//        T* newArra = new T[cap];
//        for (int i = 0; i < size; i++)
//        {
//            newArra[i] = arra[i];
//        }
//        delete[] arra;
//        arra = newArra;
//        cout << "Array has shrunk. New capacity is: " << cap << endl;
//    }
//}
//
//// Explicit instantiations
//template class Array<int>;
//template class Array<double>;
