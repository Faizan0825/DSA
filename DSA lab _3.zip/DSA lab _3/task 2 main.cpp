//#include "array.h"
//
//
//int main()
//{
//    int arrr[5] = { 1, 4, 5, 6, 2 };
//    Array<int> a(arrr, 5);
//
//    a.display();
//    cout << "The sorted array is: " << endl;
//    a.sort();
//    a.display();
//
//    a.add(10);
//    a.add(8);
//
//    a.remove();
//    a.remove();
//
//    a.add(12);
//    a.add(14);
//
//    cout << "The sorted array is: ";
//    a.sort();
//
//    return 0;
//}
