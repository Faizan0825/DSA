//#include <iostream>
//using namespace std;
//
//template<typename T>
//class Array
//{
//protected:
//    T* arra;
//    int size;
//    int cap;
//
//public:
//    Array(T* arr = nullptr, int s = 5);
//    Array(const Array& other);
//    ~Array();
//
//    void display();
//    void sort();
//    void add(T val);
//    void remove();
//    void grow(int increment);
//    void shrink();
//};
//
//
