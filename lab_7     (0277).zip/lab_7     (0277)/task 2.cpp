#include <iostream>
using namespace std;

template<typename T>
class Node
{
public:
    T data;
    Node* next;

    Node(T d)
    {
        data = d;
        next = nullptr;
    }
};

template<typename T>
class SLList
{
    Node<T>* first;

public:
    SLList()
    {
        first = nullptr;
    }

    bool isEmpty()
    {
        return first == nullptr;
    }

    void addItemAtLast(T value)
    {
        Node<T>* ptr = new Node<T>(value);
        if (isEmpty())
            first = ptr;
        else
        {
            Node<T>* curr = first;
            while (curr->next != nullptr)
                curr = curr->next;
            curr->next = ptr;
        }
    }

    void addAtFront(T value)
    {
        Node<T>* ptr = new Node<T>(value);
        if (isEmpty())
            first = ptr;
        else
        {
            ptr->next = first;
            first = ptr;
        }
    }

    void print()
    {
        if (isEmpty())
            cout << "List is Empty\n";
        else
        {
            Node<T>* curr = first;
            while (curr != nullptr)
            {
                cout << curr->data << "  ";
                curr = curr->next;
            }
            cout << endl;
        }
    }

    void addAfter(T value, T after)
    {
        Node<T>* curr = first;
        while (curr != nullptr && curr->data != after)
            curr = curr->next;

        if (curr == nullptr)
        {
            cout << "Value " << after << " not found.\n";
            return;
        }

        Node<T>* newNode = new Node<T>(value);
        newNode->next = curr->next;
        curr->next = newNode;
    }

    void addBefore(T value, T before)
    {
        if (isEmpty())
        {
            cout << "List is empty.\n";
            return;
        }

        if (first->data == before)
        {
            addAtFront(value);
            return;
        }

        Node<T>* curr = first;
        Node<T>* prev = nullptr;

        while (curr != nullptr && curr->data != before)
        {
            prev = curr;
            curr = curr->next;
        }

        if (curr == nullptr)
        {
            cout << "Value " << before << " not found.\n";
            return;
        }

        Node<T>* newNode = new Node<T>(value);
        prev->next = newNode;
        newNode->next = curr;
    }

    void addAtAny(T value)
    {
        int position;
        cout << "Enter position (0-indexed): ";
        cin >> position;

        if (position < 0)
        {
            cout << "Invalid position.\n";
            return;
        }

        if (position == 0)
        {
            addAtFront(value);
            return;
        }

        Node<T>* curr = first;
        int currentPos = 0;

        while (curr != nullptr && currentPos < position - 1)
        {
            curr = curr->next;
            currentPos++;
        }

        if (curr == nullptr)
        {
            cout << "Position out of bounds.\n";
            return;
        }

        Node<T>* newNode = new Node<T>(value);
        newNode->next = curr->next;
        curr->next = newNode;
    }

    int countNodes()
    {
        int count = 0;
        Node<T>* curr = first;
        while (curr != nullptr)
        {
            count++;
            curr = curr->next;
        }
        return count;
    }

    bool searchItem(T value)
    {
        Node<T>* curr = first;
        while (curr != nullptr)
        {
            if (curr->data == value) return true;
            curr = curr->next;
        }
        return false;
    }

    Node<T>* searchItem2(T value)
    {
        Node<T>* curr = first;
        while (curr != nullptr)
        {
            if (curr->data == value) return curr;
            curr = curr->next;
        }
        return nullptr;
    }

    Node<T>* searchItem3(T value, Node<T>*& prev)
    {
        prev = nullptr;
        Node<T>* curr = first;
        while (curr != nullptr)
        {
            if (curr->data == value) return curr;
            prev = curr;
            curr = curr->next;
        }
        return nullptr;
    }

    void removeItemFromFront(T value)
    {
        if (isEmpty())
        {
            cout << "List is empty.\n";
            return;
        }

        if (first->data == value)
        {
            Node<T>* temp = first;
            first = first->next;
            delete temp;
            cout << value << " removed from front.\n";
        }
        else
        {
            cout << value << " is not at the front.\n";
        }
    }

    void removeItemBeforeAnyNode(T value)
    {
        if (isEmpty() || first->data == value)
        {
            cout << "No node before " << value << ".\n";
            return;
        }

        Node<T>* prev = nullptr;
        Node<T>* curr = first;

        while (curr->next != nullptr && curr->next->data != value)
        {
            prev = curr;
            curr = curr->next;
        }

        if (curr->next == nullptr)
        {
            cout << value << " not found.\n";
            return;
        }

        if (prev == nullptr)
        {
            Node<T>* temp = first;
            first = curr->next;
            delete temp;
        }
        else
        {
            prev->next = curr->next;
            delete curr;
        }
        cout << "Node before " << value << " removed.\n";
    }

    void removeItemAfterAnyNode(T value)
    {
        Node<T>* curr = first;
        while (curr != nullptr && curr->data != value)
            curr = curr->next;

        if (curr == nullptr)
        {
            cout << value << " not found.\n";
            return;
        }

        if (curr->next == nullptr)
        {
            cout << "No node after " << value << ".\n";
            return;
        }

        Node<T>* temp = curr->next;
        curr->next = temp->next;
        delete temp;
        cout << "Node after " << value << " removed.\n";
    }

    void removeAnyItem(T value)
    {
        Node<T>* prev = nullptr;
        Node<T>* curr = first;

        while (curr != nullptr && curr->data != value)
        {
            prev = curr;
            curr = curr->next;
        }

        if (curr == nullptr)
        {
            cout << value << " not found.\n";
            return;
        }

        if (prev == nullptr)
            first = curr->next;
        else
            prev->next = curr->next;

        delete curr;
        cout << value << " removed.\n";
    }

    void removeNthNode(int n)
    {
        if (n < 0 || isEmpty())
        {
            cout << "Invalid position.\n";
            return;
        }

        if (n == 0)
        {
            Node<T>* temp = first;
            first = first->next;
            delete temp;
            cout << "Node at position " << n << " removed.\n";
            return;
        }

        Node<T>* curr = first;
        int currentPos = 0;

        while (curr != nullptr && currentPos < n - 1)
        {
            curr = curr->next;
            currentPos++;
        }

        if (curr == nullptr || curr->next == nullptr)
        {
            cout << "Position out of bounds.\n";
            return;
        }

        Node<T>* temp = curr->next;
        curr->next = temp->next;
        delete temp;
        cout << "Node at position " << n << " removed.\n";
    }
};

int main()
{
    SLList<int> list;
    list.addItemAtLast(12);
    list.addItemAtLast(24);
    list.addItemAtLast(36);

    cout << "Original List: ";
    list.print();

    list.addAfter(15, 12);
    cout << "After adding 15 after 12: ";
    list.print();

    list.removeAnyItem(24);
    cout << "After removing 24: ";
    list.print();

    return 0;
}
