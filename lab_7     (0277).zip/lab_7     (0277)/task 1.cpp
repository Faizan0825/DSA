#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node* next;

    Node(int d) : data(d), next(nullptr) {}
};

class SLList 
{
    Node* first;

public:
    SLList() : first(nullptr) 
    {}

    bool isEmpty() 
    {
        return first == nullptr;
    }

    void addItemAtLast(int value)
    {
        Node* ptr = new Node(value);
        if (isEmpty()) first = ptr;
        else 
        {
            Node* curr = first;
            while (curr->next != nullptr) curr = curr->next;
            curr->next = ptr;
        }
    }

    void addAtFront(int value) 
    {
        Node* ptr = new Node(value);
        if (isEmpty()) first = ptr;
        else 
        {
            ptr->next = first;
            first = ptr;
        }
    }

    void print() 
    {
        if (isEmpty()) cout << "List is Empty\n";
        else {
            Node* curr = first;
            while (curr != nullptr) 
            {
                cout << curr->data << "  ";
                curr = curr->next;
            }
            cout << endl;
        }
    }

    void addAfter(int value, int after)
    {
        Node* curr = first;
        while (curr != nullptr && curr->data != after)
            curr = curr->next;

        if (curr == nullptr)
        {
            cout << "Value " << after << " not found.\n";
            return;
        }

        Node* newNode = new Node(value);
        newNode->next = curr->next;
        curr->next = newNode;
    }

    void addBefore(int value, int before)
    {
        if (isEmpty())
        {
            cout << "List is empty.\n";
            return;
        }

        if (first->data == before)
        {
            addAtFront(value);
            return;
        }

        Node* curr = first;
        Node* prev = nullptr;

        while (curr != nullptr && curr->data != before)
        {
            prev = curr;
            curr = curr->next;
        }

        if (curr == nullptr) 
        {
            cout << "Value " << before << " not found.\n";
            return;
        }

        Node* newNode = new Node(value);
        prev->next = newNode;
        newNode->next = curr;
    }

    void addAtAny(int value) 
    {
        int position;
        cout << "Enter position (0-indexed): ";
        cin >> position;

        if (position < 0)
        {
            cout << "Invalid position.\n";
            return;
        }

        if (position == 0) 
        {
            addAtFront(value);
            return;
        }

        Node* curr = first;
        int currentPos = 0;

        while (curr != nullptr && currentPos < position - 1)
        {
            curr = curr->next;
            currentPos++;
        }

        if (curr == nullptr) 
        {
            cout << "Position out of bounds.\n";
            return;
        }

        Node* newNode = new Node(value);
        newNode->next = curr->next;
        curr->next = newNode;
    }

    int countNodes()
    {
        int count = 0;
        Node* curr = first;
        while (curr != nullptr)
        {
            count++;
            curr = curr->next;
        }
        return count;
    }

    bool searchItem(int value) 
    {
        Node* curr = first;
        while (curr != nullptr) 
        {
            if (curr->data == value) return true;
            curr = curr->next;
        }
        return false;
    }

    Node* searchItem2(int value)
    {
        Node* curr = first;
        while (curr != nullptr)
        {
            if (curr->data == value) return curr;
            curr = curr->next;
        }
        return nullptr;
    }

    Node* searchItem3(int value, Node*& prev) 
    {
        prev = nullptr;
        Node* curr = first;
        while (curr != nullptr) 
        {
            if (curr->data == value) return curr;
            prev = curr;
            curr = curr->next;
        }
        return nullptr;
    }

    void removeItemFromFront(int value) 
    {
        if (isEmpty()) 
        {
            cout << "List is empty.\n";
            return;
        }

        if (first->data == value)
        {
            Node* temp = first;
            first = first->next;
            delete temp;
            cout << value << " removed from front.\n";
        }
        else 
        {
            cout << value << " is not at the front.\n";
        }
    }

    void removeItemBeforeAnyNode(int value) 
    {
        if (isEmpty() || first->data == value) 
        {
            cout << "No node before " << value << ".\n";
            return;
        }

        Node* prev = nullptr;
        Node* curr = first;

        while (curr->next != nullptr && curr->next->data != value)
        {
            prev = curr;
            curr = curr->next;
        }

        if (curr->next == nullptr)
        {
            cout << value << " not found.\n";
            return;
        }

        if (prev == nullptr)
        {
            Node* temp = first;
            first = curr->next;
            delete temp;
        }
        else {
            prev->next = curr->next;
            delete curr;
        }
        cout << "Node before " << value << " removed.\n";
    }

    void removeItemAfterAnyNode(int value)
    {
        Node* curr = first;
        while (curr != nullptr && curr->data != value)
            curr = curr->next;

        if (curr == nullptr)
        {
            cout << value << " not found.\n";
            return;
        }

        if (curr->next == nullptr)
        {
            cout << "No node after " << value << ".\n";
            return;
        }

        Node* temp = curr->next;
        curr->next = temp->next;
        delete temp;
        cout << "Node after " << value << " removed.\n";
    }

    void removeAnyItem(int value) 
    {
        Node* prev = nullptr;
        Node* curr = first;

        while (curr != nullptr && curr->data != value) 
        {
            prev = curr;
            curr = curr->next;
        }

        if (curr == nullptr) 
        {
            cout << value << " not found.\n";
            return;
        }

        if (prev == nullptr) first = curr->next;
        else prev->next = curr->next;

        delete curr;
        cout << value << " removed.\n";
    }

    void removeNthNode(int n) 
    {
        if (n < 0 || isEmpty())
        {
            cout << "Invalid position.\n";
            return;
        }

        if (n == 0) 
        {
            Node* temp = first;
            first = first->next;
            delete temp;
            cout << "Node at position " << n << " removed.\n";
            return;
        }

        Node* curr = first;
        int currentPos = 0;

        while (curr != nullptr && currentPos < n - 1) 
        {
            curr = curr->next;
            currentPos++;
        }

        if (curr == nullptr || curr->next == nullptr) 
        {
            cout << "Position out of bounds.\n";
            return;
        }

        Node* temp = curr->next;
        curr->next = temp->next;
        delete temp;
        cout << "Node at position " << n << " removed.\n";
    }
};

int main() 
{
    SLList list;
    list.addItemAtLast(11);
    list.addItemAtLast(22);
    list.addItemAtLast(33);

    cout << "Original List: ";
    list.print();

    list.addAfter(17, 11);
    cout << "After adding 15 after 11: ";
    list.print();

    list.removeAnyItem(22);
    cout << "After removing 22: ";
    list.print();

    return 0;
}