#include <iostream>
using namespace std;

class Heap
{
private:
	int arr[100];
	int size;

	int parent(int i) { return (i - 1) / 2; }
	int leftChild(int i) { return (2 * i + 1); }
	int rightChild(int i) { return (2 * i + 2); }

	void heapifyUp(int i)
	{
		while (i > 0 && arr[i] < arr[parent(i)])
		{
			swap(arr[i], arr[parent(i)]);
			i = parent(i);
		}
	}

	void heapifyDown(int i)
	{
		int smallest = i;
		int left = leftChild(i);
		int right = rightChild(i);

		if (left < size && arr[left] < arr[smallest])
			smallest = left;

		if (right < size && arr[right] < arr[smallest])
			smallest = right;

		if (smallest != i)
		{
			swap(arr[i], arr[smallest]);
			heapifyDown(smallest);
		}
	}

public:
	Heap() : size(0) {}

	void insert(int val)
	{
		if (size == 100)
		{
			cout << "Heap is full!" << endl;
			return;
		}
		arr[size] = val;
		heapifyUp(size);
		size++;
	}

	void deleteMin()
	{
		if (size == 0)
		{
			cout << "Heap is empty!" << endl;
			return;
		}
		arr[0] = arr[size - 1];
		size--;
		heapifyDown(0);
	}

	void printHeap()
	{
		cout << "Heap: ";
		for (int i = 0; i < size; i++)
			cout << arr[i] << " ";
		cout << endl;
	}
};

// Node class for Circular Linked List
class Node
{
public:
	int data;
	Node* next;

	Node(int val) : data(val), next(nullptr) {}
};

class CircularLinkedList
{
private:
	Node* head;

public:
	CircularLinkedList() : head(nullptr) {}

	void insert(int val)
	{
		Node* newNode = new Node(val);
		if (!head)
		{
			head = newNode;
			newNode->next = head;
			return;
		}

		Node* temp = head;
		while (temp->next != head)
			temp = temp->next;

		temp->next = newNode;
		newNode->next = head;
	}

	void deleteNode(int val)
	{
		if (!head) return;

		if (head->data == val)
		{
			if (head->next == head)
			{
				delete head;
				head = nullptr;
				return;
			}

			Node* last = head;
			while (last->next != head)
				last = last->next;

			Node* del = head;
			head = head->next;
			last->next = head;
			delete del;
			return;
		}

		Node* prev = head;
		Node* curr = head->next;
		while (curr != head)
		{
			if (curr->data == val)
			{
				prev->next = curr->next;
				delete curr;
				return;
			}
			prev = curr;
			curr = curr->next;
		}
	}

	void display()
	{
		if (!head)
		{
			cout << "Circular Linked List is empty." << endl;
			return;
		}

		Node* temp = head;
		cout << "Circular Linked List: ";
		do
		{
			cout << temp->data << " ";
			temp = temp->next;
		} while (temp != head);
		cout << endl;
	}

	~CircularLinkedList()
	{
		if (!head) return;

		Node* current = head->next;
		while (current != head)
		{
			Node* temp = current;
			current = current->next;
			delete temp;
		}
		delete head;
	}
};

int main()
{
	cout << "=== Min Heap ===" << endl;
	Heap h;
	h.insert(10);
	h.insert(20);
	h.insert(5);
	h.printHeap();

	h.deleteMin();
	h.printHeap();

	h.insert(2);
	h.printHeap();

	cout << "\n=== Circular Linked List ===" << endl;
	CircularLinkedList cl;
	cl.insert(100);
	cl.insert(200);
	cl.insert(300);
	cl.display();

	cl.deleteNode(200);
	cl.display();

	cl.deleteNode(100);
	cl.display();

	system("pause");
	return 0;
}
