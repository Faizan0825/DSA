#include "MyMatrix.h"
#include <iostream>
using namespace std;

template <typename Type>
MyMatrix<Type>::MyMatrix(int r, int c) : rows(r), cols(c), lastValue(Type())
{
    if (rows > 0 && cols > 0)
    {
        matrix = new Type * [rows];
        for (int i = 0; i < rows; i++)
        {
            matrix[i] = new Type[cols];
            for (int j = 0; j < cols; j++)
            {
                matrix[i][j] = Type();
            }
        }
    }
    else {
        matrix = nullptr;
    }
}

template <typename Type>
MyMatrix<Type>::MyMatrix(const MyMatrix& other) : rows(other.rows), cols(other.cols), lastValue(other.lastValue)
{
    if (rows > 0 && cols > 0) {
        matrix = new Type * [rows];
        for (int i = 0; i < rows; i++) 
        {
            matrix[i] = new Type[cols];
            for (int j = 0; j < cols; j++)
            {
                matrix[i][j] = other.matrix[i][j];
            }
        }
    }
    else {
        matrix = nullptr;
    }
}

template <typename Type>
MyMatrix<Type>::~MyMatrix()
{
    if (matrix != nullptr) 
    {
        for (int i = 0; i < rows; i++) 
        {
            delete[] matrix[i];
        }
        delete[] matrix;
        cout << "Matrix is being deleted.\n";
    }
}

template <typename Type>
bool MyMatrix<Type>::isEmpty()
{
    return (rows == 0 || cols == 0);
}

template <typename Type>
bool MyMatrix<Type>::isFull()
{
    if (matrix == nullptr) 
    {
        return false;
    }
    for (int i = 0; i < rows; i++) 
    {
        for (int j = 0; j < cols; j++) 
        {
            if (matrix[i][j] == Type()) 
            {
                return false;
            }
        }
    }
    return true;
}

template <typename Type>
int MyMatrix<Type>::getRowSize() 
{
    return rows;
}

template <typename Type>
int MyMatrix<Type>::getColSize() 
{
    return cols;
}

template <typename Type>
bool MyMatrix<Type>::updateValue(int row, int col, Type value)
{
    if (row < 0 || row >= rows || col < 0 || col >= cols)
    {
        return false;
    }
    matrix[row][col] = value;
    lastValue = value;
    return true;
}

template <typename Type>
Type MyMatrix<Type>::getLastValue() 
{
    return lastValue;
}

template <typename Type>
bool MyMatrix<Type>::search(Type value)
{
    if (matrix == nullptr) 
    {
        return false;
    }
    for (int i = 0; i < rows; i++) 
    {
        for (int j = 0; j < cols; j++)
        {
            if (matrix[i][j] == value) 
            {
                return true;
            }
        }
    }
    return false;
}

template class MyMatrix<int>;
