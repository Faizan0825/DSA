
template <typename Type>
class MyMatrix 
{
private:
    Type** matrix;
    int rows;
    int cols;
    Type lastValue;

public:
    MyMatrix(int r = 0, int c = 0);
    MyMatrix(const MyMatrix& other);
    ~MyMatrix();

    bool isEmpty();
    bool isFull();
    int getRowSize();
    int getColSize();
    bool updateValue(int row, int col, Type value);
    Type getLastValue();
    bool search(Type value);
};

