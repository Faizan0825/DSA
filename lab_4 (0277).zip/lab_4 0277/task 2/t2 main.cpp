#include <iostream>
#include "MyMatrix.h"
using namespace std;

int main() 
{
    MyMatrix<int> myMatrix(3, 3);
    int choice;

    do {
        cout << "Menu:" << endl;
        cout << "1. Check if matrix is empty" << endl;
        cout << "2. Check if matrix is full" << endl;
        cout << "3. Get row size" << endl;
        cout << "4. Get column size" << endl;
        cout << "5. Update value" << endl;
        cout << "6. Get last value" << endl;
        cout << "7. Search value" << endl;
        cout << "0. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) 
        {
        case 1:
            cout << (myMatrix.isEmpty() ? "Matrix is empty." : "Matrix is not empty.") << endl;
            break;
        case 2:
            cout << (myMatrix.isFull() ? "Matrix is full." : "Matrix is not full.") << endl;
            break;
        case 3:
            cout << "Row size: " << myMatrix.getRowSize() << endl;
            break;
        case 4:
            cout << "Column size: " << myMatrix.getColSize() << endl;
            break;
        case 5:
        {
            int row, col, value;
            cout << "Enter row, column, and value: ";
            cin >> row >> col >> value;
            if (myMatrix.updateValue(row, col, value)) 
            {
                cout << "Value updated successfully." << endl;
            }
            else 
            {
                cout << "Invalid index!" << endl;
            }
            break;
        }
        case 6:
            cout << "Last value: " << myMatrix.getLastValue() << endl;
            break;
        case 7:
        {
            int value;
            cout << "Enter value to search: ";
            cin >> value;
            cout << (myMatrix.search(value) ? "Value found." : "Value not found.") << endl;
            break;
        }
        case 0:
            cout << "Exiting program." << endl;
            break;
        default:
            cout << "Invalid choice! Please try again." << endl;
        }
    } 
    while (choice != 0);

    return 0;
}
