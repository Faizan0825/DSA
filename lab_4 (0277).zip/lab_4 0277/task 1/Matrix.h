

    template <typename Type>
    class Matrix 
    {
    private:
        Type** arr;
        int rows;
        int cols;

    public:
        Matrix(int r = 3, int c = 3);
        Matrix(const Matrix& other);
        ~Matrix();

        void insertValue(int row, int col, Type value);
        Type getValue(int row, int col);
        void displayMatrix();
        void deleteValue(int row, int col);
        bool searchValue(Type value);
    };

