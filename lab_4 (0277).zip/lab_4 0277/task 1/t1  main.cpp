#include <iostream>
#include "Matrix.h"
using namespace std;

int main()
{
    Matrix<int> mat(3, 3);

    mat.insertValue(0, 0, 1);
    mat.insertValue(0, 1, 2);
    mat.insertValue(0, 2, 3);
    mat.insertValue(1, 0, 4);
    mat.insertValue(1, 1, 5);
    mat.insertValue(1, 2, 6);
    mat.insertValue(2, 0, 7);
    mat.insertValue(2, 1, 8);
    mat.insertValue(2, 2, 9);

    cout << "Matrix:" << endl;
    mat.displayMatrix();

    int searchVal = 5;
    cout << "Searching for value " << searchVal << ": ";
    if (mat.searchValue(searchVal)) 
    {
        cout << "Found!" << endl;
    }
    else 
    {
        cout << "Not found!" << endl;
    }

    mat.deleteValue(1, 1);
    cout << "Matrix after deleting value at (1, 1):" << endl;
    mat.displayMatrix();

    return 0;
}
