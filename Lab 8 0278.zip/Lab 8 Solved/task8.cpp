#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node(int d) : data(d), next(nullptr) {}
};

class CircularLinkedList {
    Node* head;
    Node* tail;
public:
    CircularLinkedList() : head(nullptr), tail(nullptr) {}

    void addNode(int val) {
        Node* newNode = new Node(val);
        if (!head) {
            head = tail = newNode;
            tail->next = head;
        } else {
            tail->next = newNode;
            tail = newNode;
            tail->next = head;
        }
    }

    void insertSorted(int val) {
        Node* newNode = new Node(val);
        if (!head || val < head->data) {
            if (!head) {
                head = tail = newNode;
                tail->next = head;
            } else {
                newNode->next = head;
                head = newNode;
                tail->next = head;
            }
            return;
        }
        Node* curr = head;
        while (curr->next != head && curr->next->data < val)
            curr = curr->next;
        newNode->next = curr->next;
        curr->next = newNode;
        if (curr == tail) tail = newNode;
    }

    void deleteNode(int val) {
        if (!head) return;
        Node* curr = head;
        Node* prev = tail;
        do {
            if (curr->data == val) {
                if (curr == head) {
                    if (head == tail) {
                        delete head;
                        head = tail = nullptr;
                    } else {
                        head = head->next;
                        tail->next = head;
                        delete curr;
                    }
                } else {
                    prev->next = curr->next;
                    if (curr == tail) tail = prev;
                    delete curr;
                }
                cout << "Node deleted.\n";
                return;
            }
            prev = curr;
            curr = curr->next;
        } while (curr != head);
        cout << "Node not found.\n";
    }

    bool search(int val) {
        if (!head) return false;
        Node* curr = head;
        do {
            if (curr->data == val) return true;
            curr = curr->next;
        } while (curr != head);
        return false;
    }

    void display() {
        if (!head) {
            cout << "List empty.\n";
            return;
        }
        Node* curr = head;
        do {
            cout << curr->data << " ";
            curr = curr->next;
        } while (curr != head);
        cout << endl;
    }
};

int main() {
    CircularLinkedList list;
    int choice, val;
    do {
        cout << "1. Add node\n2. Insert sorted\n3. Delete node\n4. Search node\n5. Display\n6. Exit\nEnter choice: ";
        cin >> choice;
        switch (choice) {
            case 1: cout << "Enter value: "; cin >> val; list.addNode(val); break;
            case 2: cout << "Enter value: "; cin >> val; list.insertSorted(val); break;
            case 3: cout << "Enter value to delete: "; cin >> val; list.deleteNode(val); break;
            case 4: cout << "Enter value to search: "; cin >> val; cout << (list.search(val) ? "Found\n" : "Not found\n"); break;
            case 5: list.display(); break;
            case 6: cout << "Exiting...\n"; break;
            default: cout << "Invalid choice\n";
        }
    } while (choice != 6);
    return 0;
}
