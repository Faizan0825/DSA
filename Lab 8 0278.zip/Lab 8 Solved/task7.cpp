#include <iostream>
#include <string>
using namespace std;

bool isPalindromeHelper(const string& s, int start, int end) {
    if (start >= end) return true;
    if (s[start] != s[end]) return false;
    return isPalindromeHelper(s, start + 1, end - 1);
}

bool isPalindrome(int n) {
    string s = to_string(n);
    return isPalindromeHelper(s, 0, s.length() - 1);
}

int main() {
    int n;
    cout << "Enter a number: ";
    cin >> n;
    if (isPalindrome(n)) cout << "Palindrome" << endl;
    else cout << "Not Palindrome" << endl;
    return 0;
}
