#include <iostream>
using namespace std;

struct DNode {
    int data;
    DNode* next;
    DNode* prev;
    DNode(int d) : data(d), next(nullptr), prev(nullptr) {}
};

class DoublyLinkedList {
    DNode* head;
    DNode* tail;
public:
    DoublyLinkedList() : head(nullptr), tail(nullptr) {}

    void addNode(int val) {
        DNode* newNode = new DNode(val);
        if (!head) head = tail = newNode;
        else {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
    }

    void insertSorted(int val) {
        DNode* newNode = new DNode(val);
        if (!head || val < head->data) {
            newNode->next = head;
            if (head) head->prev = newNode;
            head = newNode;
            if (!tail) tail = head;
            return;
        }
        DNode* curr = head;
        while (curr->next && curr->next->data < val)
            curr = curr->next;
        newNode->next = curr->next;
        newNode->prev = curr;
        if (curr->next) curr->next->prev = newNode;
        curr->next = newNode;
        if (!newNode->next) tail = newNode;
    }

    void deleteNode(int val) {
        DNode* curr = head;
        while (curr) {
            if (curr->data == val) {
                if (curr->prev) curr->prev->next = curr->next;
                else head = curr->next;
                if (curr->next) curr->next->prev = curr->prev;
                else tail = curr->prev;
                delete curr;
                cout << "Node deleted.\n";
                return;
            }
            curr = curr->next;
        }
        cout << "Node not found.\n";
    }

    bool search(int val) {
        DNode* curr = head;
        while (curr) {
            if (curr->data == val) return true;
            curr = curr->next;
        }
        return false;
    }

    void displayForward() {
        DNode* curr = head;
        while (curr) {
            cout << curr->data << " ";
            curr = curr->next;
        }
        cout << endl;
    }

    void displayReverse() {
        DNode* curr = tail;
        while (curr) {
            cout << curr->data << " ";
            curr = curr->prev;
        }
        cout << endl;
    }
};

int main() {
    DoublyLinkedList list;
    int choice, val;
    do {
        cout << "1. Add node\n2. Insert sorted\n3. Delete node\n4. Search node\n5. Display forward\n6. Display reverse\n7. Exit\nEnter choice: ";
        cin >> choice;
        switch (choice) {
            case 1: cout << "Enter value: "; cin >> val; list.addNode(val); break;
            case 2: cout << "Enter value: "; cin >> val; list.insertSorted(val); break;
            case 3: cout << "Enter value to delete: "; cin >> val; list.deleteNode(val); break;
            case 4: cout << "Enter value to search: "; cin >> val; cout << (list.search(val) ? "Found\n" : "Not found\n"); break;
            case 5: list.displayForward(); break;
            case 6: list.displayReverse(); break;
            case 7: cout << "Exiting...\n"; break;
            default: cout << "Invalid choice\n";
        }
    } while (choice != 7);
    return 0;
}
