#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node(int d) : data(d), next(nullptr) {}
};

int getLength(Node* head) {
    if (!head) return 0;
    Node* curr = head;
    int len = 0;
    do {
        len++;
        curr = curr->next;
    } while (curr != head);
    return len;
}

bool areEqual(Node* head1, Node* head2) {
    int len1 = getLength(head1), len2 = getLength(head2);
    if (len1 != len2) return false;
    if (!head1 && !head2) return true;
    if (!head1 || !head2) return false;
    Node *curr1 = head1, *curr2 = head2;
    do {
        if (curr1->data != curr2->data) return false;
        curr1 = curr1->next;
        curr2 = curr2->next;
    } while (curr1 != head1 && curr2 != head2);
    return true;
}
