//#include<iostream>
//using namespace std;
//int main()
//{
//	double price;
//	cout << "Enter the price of car = ";
//	cin >> price;
//
//	double div = price * 0.12;
//	div = div + 15000;
//	double *p = &div;
//	cout << "The 12% of this car is " << *p << endl;
//
//
//
//
//	return 0;
//}