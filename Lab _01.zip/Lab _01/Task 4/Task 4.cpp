class Rectangle
{
protected:
	double len;
	double widht;

public:
	Rectangle(double lenght = 1, double wid = 1);
	void setwid(double wi);
	void setlen(double l);
	double getl();
	double getw();
	double perimeter();
};
