//#include<iostream>
//using namespace std;
//int main()
//{
//
// float  a, b;
//	cout << "Enter first value : ";
//	cin >> a;
//
//
//	cout << "Enter second value : ";
//	cin >> b;
//
//	float cal = 0;
//	cal= a + b;
//	float* Sum = &cal;
//	cout << "The sum is " << *Sum << endl;
//
//	cal = a * b;
//
//	float* mul = &cal;
//	cout << "The sum is " << *mul << endl;
//
//
//	cal = a /b;
//
//	float* div = &cal;
//
//	cout << "The sum is " << *div << endl;
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//	return 0;
//}