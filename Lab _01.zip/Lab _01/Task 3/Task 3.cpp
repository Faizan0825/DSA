//#include <iostream>
//#include <fstream>
//using namespace std;
//
//int findNearestIndex(int* arr, int size, int key) 
//{
//	for (int i = 0; i < size; i++) 
//	{
//		if (arr[i] == key)
//			return i;
//		if (arr[i] > key)
//		{
//			if (i == 0) 
//			{
//				return i;
//			}
//			else 
//			{
//				return i - 1;
//			}
//		}
//	}
//	return size - 1;
//}
//
//int main() {
//	ifstream fin("Data.txt");
//	
//	int size = 0, key;
//	fin >> size;
//	cout << "Size: " << size << endl;
//
//	int* arr = new int[size];
//	for (int i = 0; i < size; i++) 
//	{
//		fin >> arr[i];
//		cout << arr[i] << " ";
//	}
//	cout << endl;
//
//	fin >> key;
//	fin.close();
//
//	int index = findNearestIndex(arr, size, key);
//	cout << "Nearest Index: " << index << endl;
//
//	delete[] arr;
//	system("pause");
//	return 0;
//}
