//#include <iostream>
//
//class CarbonFootprint 
//{
//public:
//    virtual double getCarbonFootprint() const = 0; 
//    virtual ~CarbonFootprint() {} 
//};
//
//class Electricity : public CarbonFootprint 
//{
//private:
//    double averageBillPerMonth; 
//    double pricePerKwh = 8.00; 
//    double emissionsFactor = 1.37; 
//
//public:
//    Electricity(double bill) : averageBillPerMonth(bill) {}
//    double getCarbonFootprint() const override;
//};
//
//class NaturalGas : public CarbonFootprint 
//{
//private:
//    double averageBillPerMonth; 
//    double pricePerCubicFeet = 3.00; 
//    double emissionsFactor = 120.61; 
//
//public:
//    NaturalGas(double bill) : averageBillPerMonth(bill) {}
//    double getCarbonFootprint() const override;
//};
//
//class Vehicle : public CarbonFootprint 
//{
//private:
//    double milesDrivenPerWeek; 
//    double fuelEfficiency; 
//    double emissionsPerGallon = 19.6; 
//    double greenhouseGasFactor = 1.1; 
//
//public:
//    Vehicle(double miles, double efficiency) : milesDrivenPerWeek(miles), fuelEfficiency(efficiency) {}
//    double getCarbonFootprint() const override;
//};
//
//void display(CarbonFootprint* object);
//
