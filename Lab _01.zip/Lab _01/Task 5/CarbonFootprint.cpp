//#include "CarbonFootprint.h"
//
//using namespace std;
//
//
//double Electricity::getCarbonFootprint() const
//{
//    return averageBillPerMonth / pricePerKwh * emissionsFactor * 12; 
//}
//
//
//double NaturalGas::getCarbonFootprint() const 
//{
//    return averageBillPerMonth / pricePerCubicFeet * emissionsFactor * 12;
//}
//
//
//double Vehicle::getCarbonFootprint() const 
//{
//    return ((milesDrivenPerWeek * 52) / fuelEfficiency) * emissionsPerGallon * greenhouseGasFactor;
//}
//
//
//void display(CarbonFootprint* object) 
//{
//    cout << "Carbon Footprint: " << object->getCarbonFootprint() << " pounds of CO2 per year." << endl;
//}
