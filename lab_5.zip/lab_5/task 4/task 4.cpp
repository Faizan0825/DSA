#include <iostream>
using namespace std;

class Stack {
	char arr[100];
	int top;

public:
	Stack() 
	{
		top = -1;
	}

	void push(char ch)
	{
		if (!isFull()) 
		{
			top++;
			arr[top] = ch;
		}
	}

	void pop(char& ch)
	{
		if (!isEmpty())
		{
			ch = arr[top];
			top--;
		}
	}

	void peek(char& ch) 
	{
		if (!isEmpty())
		{
			ch = arr[top];
		}
	}

	bool isEmpty() 
	{
		return top == -1;
	}

	bool isFull() 
	{
		return top == 99;
	}

	bool isTop(char expected)
	{
		if (!isEmpty()) 
		{
			return arr[top] == expected;
		}
		return false;
	}

	void getTopPrecedence(int& prec)
	{
		prec = 0;
		if (!isEmpty())
		{
			char op = arr[top];
			if (op == '+' || op == '-')
			{
				prec = 1;
			}
			else if (op == '*' || op == '/') {
				prec = 2;
			}
		}
	}
};

bool isOperand(char ch) 
{
	return (ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9');
}

bool isOperator(char ch) 
{
	return ch == '+' || ch == '-' || ch == '*' || ch == '/';
}

void getPrecedence(char op, int& prec) 
{
	prec = 0;
	if (op == '+' || op == '-') 
	{
		prec = 1;
	}
	else if (op == '*' || op == '/')
	{
		prec = 2;
	}
}

int main()
{
	const int SIZE = 100;
	char infix[SIZE];
	char postfix[SIZE];

	cout << "Enter an infix expression: ";
	cin.getline(infix, SIZE);

	Stack s;
	int i = 0, j = 0;
	char ch, topOp;
	int topPrec, curPrec;

	while (infix[i] != '\0')
	{
		ch = infix[i];

		if (isOperand(ch))
		{
			postfix[j++] = ch;
		}
		else if (ch == '(')
		{
			s.push(ch);
		}
		else if (ch == ')') 
		{
			while (!s.isEmpty() && !s.isTop('('))
			{
				s.pop(topOp);
				postfix[j++] = topOp;
			}
			if (!s.isEmpty()) 
			{
				s.pop(topOp); 
			}
		}
		else if (isOperator(ch)) 
		{
			getPrecedence(ch, curPrec);
			s.getTopPrecedence(topPrec);
			while (!s.isEmpty() && curPrec <= topPrec)
			{
				s.pop(topOp);
				postfix[j++] = topOp;
				s.getTopPrecedence(topPrec);
			}
			s.push(ch);
		}

		i++;
	}

	while (!s.isEmpty()) 
	{
		s.pop(topOp);
		postfix[j++] = topOp;
	}

	postfix[j] = '\0';

	cout << "Postfix expression: " << postfix << endl;

	system("pause");
	return 0;
}