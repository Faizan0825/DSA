class Palindrome

{
	bool isPalindrome(const char* str);
};