#include "Stack.h"

Stack::Stack() 
{
    size = 1000;
    crsize = 0;
}

bool Stack::isEmpty() const 
{
    return crsize == 0;
}

bool Stack::isFull() const 
{
    return crsize == size;
}

void Stack::push(char value)
{
    if (!isFull())
    {
        arr[crsize++] = value;
    }
}

char Stack::pop() 
{
    if (!isEmpty())
    {
        return arr[--crsize];
    }
    return '\0'; 
}

char Stack::top() const
{
    if (!isEmpty()) 
    {
        return arr[crsize - 1];
    }
    return '\0'; 
}
