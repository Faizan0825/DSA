#include "Stack.h"
#include "Palindrome.h"
#include <cstring>

bool isPalindrome(const char* str) 
{
    Stack s;
    int len = strlen(str);
    for (int i = 0; i < len; i++)
    {
        s.push(str[i]);
    }
    for (int i = 0; i < len; i++)
    {
        if (s.pop() != str[i]) 
        {
            return false;
        }
    }
    return true;
}
