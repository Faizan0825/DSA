class Stack 
{
private:
    char arr[1000];
    int size;
    int crsize;

public:
    Stack();

    bool isEmpty() const;
    bool isFull() const;
    void push(char value);
    char pop();
    char top() const;
};

