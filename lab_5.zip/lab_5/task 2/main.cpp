#include <iostream>
#include "Stack.h"

using namespace std;

int main() {
    char num1[] = "987654321987654321987654321987654321";
    char num2[] = "123456789123456789123456789123456789";

    Stack s1, s2, result;

    int len1 = 0, len2 = 0;
    while (num1[len1] != '\0') len1++;
    while (num2[len2] != '\0') len2++;

    for (int i = len1 - 1; i >= 0; i--) 
    {
        s1.push(num1[i]);
    }
    for (int i = len2 - 1; i >= 0; i--) 
    {
        s2.push(num2[i]);
    }

    int carry = 0;

    while (!s1.isEmpty() || !s2.isEmpty() || carry > 0) 
    {
        int digit1 = (!s1.isEmpty()) ? s1.pop() - '0' : 0;
        int digit2 = (!s2.isEmpty()) ? s2.pop() - '0' : 0;

        int sum = digit1 + digit2 + carry;
        carry = sum / 10;
        sum %= 10;

        result.push(sum + '0');
    }

    cout << "Sum = ";
    while (!result.isEmpty()) 
    {
        cout << result.pop();
    }
    cout << endl;

    return 0;
}
