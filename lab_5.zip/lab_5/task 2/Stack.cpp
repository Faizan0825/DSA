#include "Stack.h"

Stack::Stack()
{
    top = -1;
}

bool Stack::isEmpty() 
{
    return top == -1;
}

bool Stack::isFull()
{
    return top == 999;
}

void Stack::push(char ch)
{
    if (!isFull())
    {
        data[++top] = ch;
    }
}

char Stack::pop() 
{
    if (!isEmpty()) 
    {
        return data[top--];
    }
    return '0';
}

char Stack::peek()
{
    if (!isEmpty()) 
    {
        return data[top];
    }
    return '0';
}
