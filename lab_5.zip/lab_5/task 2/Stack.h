
class Stack
{
    char data[1000];
    int top;

public:
    Stack();

    bool isEmpty();
    bool isFull();
    void push(char ch);
    char pop();
    char peek();
};
