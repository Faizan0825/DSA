#include<iostream>
#include"Abstractstack.h"
#include"mystack.h"

    using namespace std; 

    int main() 
{
        MyStack<int> stack(5);
        int choice, value;

        do 
{
            cout << "1. Push" << endl;
            cout << "2. Pop\n"; 
            cout << " 3.Top\n"; 
            cout << "4.Display\n";
            cout<<"5.Exit\n";

            cout << "Enter your choice: ";
            cin >> choice;

            switch (choice) 
{
            case 1:
                cout << "Enter value to push: ";
                cin >> value;
                stack.push(value);
                break;
            case 2:
                cout << "Popped value: " << stack.pop() << endl;
                break;
            case 3:
                cout << "Top value: " << stack.top() << endl;
                break;
            case 4:
                stack.display();
                break;
            case 5:
                cout << "Exiting program.\n";
                break;
            default:
                cout << "Invalid choice. Try again.\n";
            }
        } 
while (choice != 5);
		return 0;
 
}