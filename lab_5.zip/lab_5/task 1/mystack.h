
#include "AbstractStack.h"
#include <iostream>

using namespace std; 

template <typename T>
class MyStack : public AbstractStack<T> 
{
private:
    T* arr;
    int topIndex;
    int capacity;

public:
    MyStack(int size);
    ~MyStack();

    void push(T value) override;
    T pop() override;
    T top() const override;
    bool isEmpty() const override;
    bool isFull() const override;
    void display() const;
};