#include "MyStack.h"

using namespace std; 

template <typename T>
MyStack<T>::MyStack(int size) 
{
    arr = new T[size];
    capacity = size;
    topIndex = -1;
}

template <typename T>
MyStack<T>::~MyStack()
{
    delete[] arr;
}

template <typename T>
void MyStack<T>::push(T value)
{
    if (isFull())
    {
        cout << "Stack is full." << endl;
        return;
    }
    arr[++topIndex] = value;
}

template <typename T>
T MyStack<T>::pop() 
{
    if (isEmpty())
    {
        cout << "Stack is empty." << endl;
        return T(); 
    }
    return arr[topIndex--];
}

template <typename T>
T MyStack<T>::top() const 
{
    if (isEmpty()) 
    {
        cout << "Stack is empty." << endl;
        return T();
    }
    return arr[topIndex];
}

template <typename T>
bool MyStack<T>::isEmpty() const 
{
    return topIndex == -1;
}

template <typename T>
bool MyStack<T>::isFull() const
{
    return topIndex == capacity - 1;
}

template <typename T>
void MyStack<T>::display() const 
{
    if (isEmpty()) {
        cout << "Stack is empty" << endl;
        return;
    }
    cout << "Stack elements: ";
    for (int i = 0; i <= topIndex; i++) 
    {
        cout << arr[i] << " ";
    }
    cout << endl;
}
