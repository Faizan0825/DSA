#include <iostream>
#include "TwoDArray.h"

int main() {
    int rows, cols;
    cout << "Enter number of rows: ";
    cin >> rows;
    cout << "Enter number of columns: ";
    cin >> cols;

    TwoDArray<int> mat(rows, cols);

    cout << "Enter the values for the matrix:" << endl;
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            int value;
            cout << "Enter value for element [" << i << "][" << j << "]: ";
            cin >> value;
            mat.addValue(i, j, value);
        }
    }

    int choice;
    do {
        cout << "\nMenu:" << endl;
        cout << "1. Add Value" << endl;
        cout << "2. Remove Value" << endl;
        cout << "3. Display Matrix" << endl;
        cout << "4. Search Value" << endl;
        cout << "5. Sort Matrix" << endl;
        cout << "6. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
        {
            int row, col, value;
            cout << "Enter row, column, and value to add: ";
            cin >> row >> col >> value;
            mat.addValue(row, col, value);
            cout << "Added value " << value << " at position [" << row << "][" << col << "]." << endl;
            break;
        }
        case 2:
        {
            int row, col;
            cout << "Enter row and column to remove value: ";
            cin >> row >> col;
            int removed = mat.removeValue(row, col);
            cout << "Removed value " << removed << " at position [" << row << "][" << col << "]." << endl;
            break;
        }
        case 3:
            cout << "Displaying Matrix:" << endl;
            mat.print();
            break;
        case 4:
        {
            int searchVal;
            cout << "Enter value to search: ";
            cin >> searchVal;
            if (!mat.searchValue(searchVal))
            {
                cout << "Value " << searchVal << " not found in matrix." << endl;
            }
            break;
        }
        case 5:
            mat.sortMatrix();
            cout << "Matrix sorted in ascending order:" << endl;
            mat.print();
            break;
        case 6:
            cout << "Exiting program." << endl;
            break;
        default:
            cout << "Invalid choice" << endl;
        }
    } while (choice != 6);

    return 0;
}
