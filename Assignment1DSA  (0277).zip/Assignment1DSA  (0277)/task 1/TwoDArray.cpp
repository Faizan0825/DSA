#include<iostream>
#include"TwoDArray.h"

template <typename Type>
TwoDArray<Type>::TwoDArray(int ro, int col)
{
    rows = ro;
    cols = col;
    Array = new Type * [rows];
    for (int i = 0; i < rows; i++)
    {
        Array[i] = new Type[cols];
    }
}

template <typename Type>
TwoDArray<Type>::~TwoDArray()
{
    for (int i = 0; i < rows; i++)
    {
        delete[] Array[i];
    }
    delete[] Array;
}

template <typename Type>
void TwoDArray<Type>::addValue(int row, int col, Type value)
{
    if (row >= 0 && row < rows && col >= 0 && col < cols)
    {
        Array[row][col] = value;
    }
    else
    {
        cout << "Invalid index " << endl;
    }
}

template <typename Type>
void TwoDArray<Type>::print()
{
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            cout << Array[i][j] << " ";
        }
        cout << endl;
    }
}

template <typename Type>
bool TwoDArray<Type>::searchValue(Type value)
{
    bool found = false;
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            if (Array[i][j] == value)
            {
                cout << "Value " << value << " found at position [" << i << "][" << j << "]." << endl;
                found = true;
            }
        }
    }
    return found;
}

template <typename Type>
Type TwoDArray<Type>::removeValue(int row, int col)
{
    if (row >= 0 && row < rows && col >= 0 && col < cols)
    {
        Type removed = Array[row][col];
        Array[row][col] = Type();
        return removed;
    }
    else
    {
        cout << "Invalid index" << endl;
        return Type();
    }
}

template <typename Type>
void TwoDArray<Type>::sortMatrix()
{
    int total = rows * cols;
    Type* flat = new Type[total];

    int k = 0;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++)
        {
            flat[k++] = Array[i][j];
        }
    }

    for (int i = 0; i < total - 1; i++) {
        for (int j = 0; j < total - 1 - i; j++)
        {
            if (flat[j] > flat[j + 1]) {
                Type temp = flat[j];
                flat[j] = flat[j + 1];
                flat[j + 1] = temp;
            }
        }
    }

    k = 0;
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            Array[i][j] = flat[k++];
        }
    }

    delete[] flat;
}

