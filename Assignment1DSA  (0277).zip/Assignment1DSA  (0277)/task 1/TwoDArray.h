

#include <iostream>
using namespace std;

template <typename Type>
class TwoDArray
{
private:
    Type** Array;
    int rows;
    int cols;

public:
    TwoDArray(int ro = 3, int col = 3);
    ~TwoDArray();

    void addValue(int row, int col, Type value);
    void print();
    bool searchValue(Type value);
    Type removeValue(int row, int col);
    void sortMatrix();
};
