#include "Sport.h"


Sport::Sport()
{
	sportName = nullptr;
	teams = 5;
	day = 1;
	month = 1;
	year = 20005;
}


Sport::Sport(const char* nam, int dy, int mon, int yr, int tem) 
{
	int len = 0;
	while (nam[len] != '\0')
	{
		len++;
	}
	sportName = new char[len + 1];
	for (int i = 0; i < len; i++)
	{
		sportName[i] = nam[i];
	}
	sportName[len] = '\0';

	day = dy;
	month = mon;
	year = yr;
	teams = tem;
}


Sport::~Sport() 
{
	if (sportName != nullptr)
	{
		delete[] sportName;
		sportName = nullptr;
	}
}


void Sport::setSportName(const char* n)
{
	if (sportName != nullptr)
	{
		delete[] sportName;
		sportName = nullptr;
	}

	int len = 0;
	while (n[len] != '\0')
	{
		len++;
	}

	sportName = new char[len + 1];
	for (int i = 0; i < len; i++)
	{
		sportName[i] = n[i];
	}
	sportName[len] = '\0';
}

const char* Sport::getSportName() const
{
	return sportName;
}


void Sport::setTeamCount(int t) 
{
	teams = (t < 0) ? 5 : t;
}

void Sport::setNextGameDate(int dy, int mon, int yr)
{
	day = (dy >= 1 && dy <= 31) ? dy : 1;
	month = (mon >= 1 && mon <= 12) ? mon : 1;
	year = (yr >= 1950 && yr <= 2100) ? yr : 2005;
}

int Sport::getGameDay() const
{
	return day; 
}
int Sport::getGameMonth() const 
{
	return month;
}
int Sport::getGameYear() const 
{
	return year; 
}


ostream& operator<<(ostream& out, const Sport& s)
{
	out << "Sport Name: " << s.sportName << endl;
	out << "Next Game Date: " << s.day << "/" << s.month << "/" << s.year << endl;
	out << "Number of Teams: " << s.teams << endl;
	return out;
}

Sport& Sport::operator=(const Sport& other)
{
	if (this != &other)
	{
		if (sportName != nullptr)
		{
			delete[] sportName;
			sportName = nullptr;
		}

		int len = 0;
		while (other.sportName[len] != '\0') len++;
		{
			sportName = new char[len + 1];
			for (int i = 0; i < len; i++)
			{
				sportName[i] = other.sportName[i];
			}
			sportName[len] = '\0';

			day = other.day;
			month = other.month;
			year = other.year;
			teams = other.teams;
		}
		return *this;
	}
}

bool Sport::operator==(const Sport& other) 
{
	return (day == other.day && month == other.month && year == other.year);
}

bool Sport::isGameEarlierThan(const Sport& other) const
{
	if (year != other.year)
	{
		return year < other.year;
	}
	if (month != other.month)
	{
		return month < other.month;
		return day < other.day;
	}
}
