#include "Sport.h"
#include<iostream>
using namespace std;

int main()
{
	Sport spr1("Football", 5, 5, 2025, 5);
	Sport spr2;

	spr2.setSportName("Cricket");
	spr2.setTeamCount(11);
	spr2.setNextGameDate(5, 3, 2025);

	

	cout << spr1 << endl;
	cout << spr2 << endl;


	if (spr1 == spr2)
	{
		cout << "Both sports have the game on the same date." << endl;
	}
	else if (spr1.isGameEarlierThan(spr2))
	{
		cout << spr1.getSportName() << " game is earlier." << endl;
	}
	else
	{

		cout << spr2.getSportName() << " game is earlier." << endl;
	}

	return 0;
}
