#include <iostream>
using namespace std;

class Sport
{
private:
	char* sportName;
	int teams;
	int day;
	int month;
	int year;

public:
	Sport(); 
	Sport(const char* nam, int dy, int mon, int yr, int tem); 
	~Sport(); 

	void setSportName(const char* n);
	const char* getSportName() const;

	void setTeamCount(int t);
	void setNextGameDate(int d, int m, int y);

	int getGameDay() const;
	int getGameMonth() const;
	int getGameYear() const;

	friend ostream& operator<<(ostream& out, const Sport& s);
	Sport& operator=(const Sport& other);

	bool operator==(const Sport& other);
	bool isGameEarlierThan(const Sport& other) const;
};


